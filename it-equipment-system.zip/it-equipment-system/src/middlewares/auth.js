const db = require('../config/db');

const requireAuth = async (req, res, next) => {
  const userId = req.session?.user?.id;
  if (!userId) {
    return res.status(401).json({ error: 'กรุณาเข้าสู่ระบบก่อนใช้งาน' });
  }

  try {
    const result = await db.query(
      `SELECT u.id, u.username, u.role_id, r.name AS role_name
       FROM users u
       LEFT JOIN roles r ON r.id = u.role_id
       WHERE u.id = $1`,
      [userId]
    );

    if (result.rows.length === 0) {
      req.session.destroy((error) => {
        if (error) console.error('Invalid session cleanup error:', error);
        return res.status(401).json({ error: 'บัญชีผู้ใช้ไม่ถูกต้อง กรุณาเข้าสู่ระบบอีกครั้ง' });
      });
      return;
    }

    req.session.user = result.rows[0];
    return next();
  } catch (error) {
    console.error('Authentication middleware error:', error);
    return res.status(500).json({ error: 'เกิดข้อผิดพลาดในการตรวจสอบการเข้าสู่ระบบ' });
  }
};

const checkPermission = (permissionName) => {
  return async (req, res, next) => {
    try {
      if (!req.session?.user) {
        return res.status(401).json({ error: 'ไม่พบสถานะการเข้าสู่ระบบ' });
      }

      const { id: userId, username } = req.session.user;
      const userResult = await db.query(
        'SELECT role_id FROM users WHERE id = $1',
        [userId]
      );
      const roleId = userResult.rows[0]?.role_id;
      if (roleId == null) {
        return res.status(401).json({ error: 'บัญชีผู้ใช้ไม่ถูกต้อง กรุณาเข้าสู่ระบบอีกครั้ง' });
      }

      req.session.user.role_id = roleId;
      if (Number(roleId) === 1) return next();

      const result = await db.query(`
        SELECT 1
        FROM role_permissions rp
        JOIN permissions p ON p.id = rp.permission_id
        WHERE rp.role_id = $1 AND p.name = $2
      `, [roleId, permissionName]);

      if (result.rows.length > 0) return next();

      await db.query(
        `INSERT INTO system_logs (user_id, username, action, resource, result_status, ip_address)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [userId, username, 'ACCESS_DENIED', req.originalUrl, 'DENIED', req.ip]
      );

      return res.status(403).json({ error: 'คุณไม่มีสิทธิ์ใช้งานส่วนนี้ (403 Forbidden)' });
    } catch (error) {
      console.error('ACL Middleware Error:', error);
      return res.status(500).json({ error: 'เกิดข้อผิดพลาดในการตรวจสอบสิทธิ์' });
    }
  };
};

const requireAnyPermission = (permissionNames) => {
  return async (req, res, next) => {
    if (!req.session?.user?.id) {
      return res.status(401).json({ error: 'กรุณาเข้าสู่ระบบก่อนใช้งาน' });
    }

    try {
      const result = await db.query(
        `SELECT u.role_id, p.name
         FROM users u
         LEFT JOIN role_permissions rp ON rp.role_id = u.role_id
         LEFT JOIN permissions p ON p.id = rp.permission_id
         WHERE u.id = $1`,
        [req.session.user.id]
      );
      const roleId = result.rows[0]?.role_id;
      if (roleId == null) {
        return res.status(401).json({ error: 'บัญชีผู้ใช้ไม่ถูกต้อง กรุณาเข้าสู่ระบบอีกครั้ง' });
      }

      req.session.user.role_id = roleId;
      if (Number(roleId) === 1 ||
          result.rows.some((row) => permissionNames.includes(row.name))) {
        return next();
      }

      await db.query(
        `INSERT INTO system_logs (user_id, username, action, resource, result_status, ip_address)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [req.session.user.id, req.session.user.username, 'ACCESS_DENIED', req.originalUrl, 'DENIED', req.ip]
      );
      return res.status(403).json({ error: 'คุณไม่มีสิทธิ์ใช้งานส่วนนี้' });
    } catch (error) {
      console.error('ACL middleware error:', error);
      return res.status(500).json({ error: 'เกิดข้อผิดพลาดในการตรวจสอบสิทธิ์' });
    }
  };
};

const requireRoleId = (roleId) => {
  return async (req, res, next) => {
    if (!req.session?.user?.id) {
      return res.status(401).json({ error: 'กรุณาเข้าสู่ระบบก่อนใช้งาน' });
    }

    try {
      const result = await db.query(
        'SELECT role_id FROM users WHERE id = $1',
        [req.session.user.id]
      );
      const currentRoleId = Number(result.rows[0]?.role_id);
      if (currentRoleId !== 1 && currentRoleId !== roleId) {
        return res.status(403).json({ error: 'คุณไม่มีสิทธิ์เข้าถึงหน้านี้' });
      }

      req.session.user.role_id = currentRoleId;
      return next();
    } catch (error) {
      console.error('Role authorization error:', error);
      return res.status(500).json({ error: 'เกิดข้อผิดพลาดในการตรวจสอบสิทธิ์' });
    }
  };
};

module.exports = { requireAuth, requireRoleId, checkPermission, requireAnyPermission };
