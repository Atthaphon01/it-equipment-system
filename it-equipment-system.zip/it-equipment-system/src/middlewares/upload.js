const fs = require('fs');
const multer = require('multer');
const path = require('path');

const uploadDirectory = path.join(__dirname, '../../public/uploads');
fs.mkdirSync(uploadDirectory, { recursive: true });
const extensionByMimeType = {
  'image/jpeg': '.jpg',
  'image/png': '.png',
  'application/pdf': '.pdf'
};

const storage = multer.diskStorage({
  destination: uploadDirectory,
  filename: (req, file, callback) => {
    const extension = extensionByMimeType[file.mimetype];
    if (!extension) return callback(new Error('ไม่อนุญาตให้ใช้ชนิดไฟล์นี้'));

    const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
    callback(null, `${file.fieldname}-${uniqueSuffix}${extension}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, callback) => {
    const allowedMimeTypes = ['image/jpeg', 'image/png', 'application/pdf'];
    if (allowedMimeTypes.includes(file.mimetype)) return callback(null, true);

    req.fileValidationError = 'อนุญาตเฉพาะไฟล์ .jpg, .png และ .pdf เท่านั้น!';
    callback(null, false);
  }
});

module.exports = upload;
