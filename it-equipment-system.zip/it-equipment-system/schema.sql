-- 1. สร้างตาราง บทบาท (Roles)
CREATE TABLE roles (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT
);

-- 2. สร้างตาราง สิทธิ์ (Permissions)
CREATE TABLE permissions (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT
);

-- 3. สร้างตาราง ความสัมพันธ์ Role x Permission (ACL)
CREATE TABLE role_permissions (
    role_id INT REFERENCES roles(id) ON DELETE CASCADE,
    permission_id INT REFERENCES permissions(id) ON DELETE CASCADE,
    PRIMARY KEY (role_id, permission_id)
);

-- 4. สร้างตาราง ผู้ใช้งาน (Users)
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role_id INT REFERENCES roles(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 5. สร้างตาราง อุปกรณ์ (Equipments)
CREATE TABLE equipments (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    serial_number VARCHAR(50) UNIQUE NOT NULL,
    image_url VARCHAR(255),
    status VARCHAR(20) DEFAULT 'AVAILABLE' -- AVAILABLE, RESERVED, BORROWED
);

-- 6. สร้างตาราง คำขอยืมอุปกรณ์ (Borrow Requests)
CREATE TABLE borrow_requests (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id),
    equipment_id INT REFERENCES equipments(id),
    status VARCHAR(20) DEFAULT 'PENDING', -- PENDING, APPROVED, REJECTED, BORROWED, RETURNED
    document_path VARCHAR(255),
    borrow_date DATE DEFAULT CURRENT_DATE,
    return_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 7. สร้างตาราง บันทึกประวัติใช้งาน (System Audit Logs)
CREATE TABLE system_logs (
    id SERIAL PRIMARY KEY,
    user_id INT,
    username VARCHAR(50),
    action VARCHAR(100) NOT NULL,
    resource VARCHAR(100),
    result_status VARCHAR(20) NOT NULL,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ====================================================
-- ข้อมูลเริ่มต้น (Initial Seed Data)
-- ====================================================

-- เพิ่ม 4 Role บังคับตามโจทย์ (Admin, Manager, Staff, GeneralUser)
INSERT INTO roles (id, name, description) VALUES
(1, 'Admin', 'ผู้ดูแลระบบสูงสุด เข้าถึงและจัดการได้ทุกฟังก์ชัน'),
(2, 'Manager', 'ผู้จัดการ อนุมัติ/ปฏิเสธคำขอยืม และดูรายงาน Log'),
(3, 'Staff', 'เจ้าหน้าที่ จัดการเพิ่ม/แก้ไขอุปกรณ์ และปรับสถานะรับ-คืน'),
(4, 'GeneralUser', 'ผู้ใช้ทั่วไป ส่งคำขอยืม และดูรายการของตนเอง');

-- เพิ่ม Permissions ตัวอย่าง
INSERT INTO permissions (name, description) VALUES
('equipment.read', 'ดูรายการอุปกรณ์'),
('equipment.create', 'เพิ่มอุปกรณ์ใหม่'),
('equipment.update', 'แก้ไขอุปกรณ์'),
('borrow.request', 'ส่งคำขอยืมอุปกรณ์'),
('borrow.approve', 'อนุมัติ/ปฏิเสธ คำขอยืม'),
('borrow.manage_return', 'จัดการการรับ-คืนอุปกรณ์'),
('admin.manage', 'จัดการ User, Role, ACL และดู Log ทั้งหมด'),
('log.read', 'เปิดดู System Log ย้อนหลัง');

-- กำหนด ACL เริ่มต้น (Role Permissions Mapping)
INSERT INTO role_permissions (role_id, permission_id) VALUES
(2, (SELECT id FROM permissions WHERE name='equipment.read')),
(2, (SELECT id FROM permissions WHERE name='borrow.approve')),
(2, (SELECT id FROM permissions WHERE name='log.read')),
(3, (SELECT id FROM permissions WHERE name='equipment.read')),
(3, (SELECT id FROM permissions WHERE name='equipment.create')),
(3, (SELECT id FROM permissions WHERE name='equipment.update')),
(3, (SELECT id FROM permissions WHERE name='borrow.manage_return')),
(4, (SELECT id FROM permissions WHERE name='equipment.read')),
(4, (SELECT id FROM permissions WHERE name='borrow.request'));

-- เพิ่ม User เริ่มต้น (รหัสผ่านของทุกลำดับคือ "123456" ซึ่งผ่านการ Hash ด้วย bcrypt แล้ว)
INSERT INTO users (username, password_hash, role_id) VALUES
('admin_user', '$2b$10$1XhyMOno6xJQYHMKbnxMA.uwENBhu0Kzn4iUfBVwJMUP.3mrZCEmi', 1),
('manager_user', '$2b$10$1XhyMOno6xJQYHMKbnxMA.uwENBhu0Kzn4iUfBVwJMUP.3mrZCEmi', 2),
('staff_user', '$2b$10$1XhyMOno6xJQYHMKbnxMA.uwENBhu0Kzn4iUfBVwJMUP.3mrZCEmi', 3),
('general_user', '$2b$10$1XhyMOno6xJQYHMKbnxMA.uwENBhu0Kzn4iUfBVwJMUP.3mrZCEmi', 4);

-- Sample inventory for a fresh project setup; replace these demo serial numbers with physical inventory.
INSERT INTO equipments (name, serial_number, status)
SELECT seed.name, seed.serial_number, 'AVAILABLE'
FROM (VALUES
    ('Laptop Dell Latitude 5440', 'DEMO-LAP-001'),
    ('Projector Epson EB-X06', 'DEMO-PRJ-001'),
    ('Monitor Dell 24-inch', 'DEMO-MON-001'),
    ('Webcam Logitech C920', 'DEMO-CAM-001'),
    ('Microphone USB Conference', 'DEMO-MIC-001')
) AS seed(name, serial_number)
WHERE NOT EXISTS (
    SELECT 1 FROM equipments WHERE serial_number = seed.serial_number
);

SELECT setval(
    pg_get_serial_sequence('equipments', 'id'),
    COALESCE(MAX(id), 1),
    COUNT(*) > 0
)
FROM equipments;

SELECT setval(
    pg_get_serial_sequence('roles', 'id'),
    COALESCE(MAX(id), 1),
    COUNT(*) > 0
)
FROM roles;