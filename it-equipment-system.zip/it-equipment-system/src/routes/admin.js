const express = require('express');
const bcrypt = require('bcrypt');
const db = require('../config/db');

const router = express.Router();

const requireAdmin = async (req, res, next) => {
  if (!req.session?.user?.id) {
    return res.status(401).json({ error: 'กรุณาเข้าสู่ระบบก่อนใช้งาน' });
  }

  try {
    const result = await db.query(
      'SELECT 1 FROM users WHERE id = $1 AND role_id = 1',
      [req.session.user.id]
    );

    if (result.rows.length === 0) {
      return res.status(403).json({ error: 'เฉพาะผู้ดูแลระบบเท่านั้นที่ใช้งานส่วนนี้ได้' });
    }

    return next();
  } catch (error) {
    console.error('Admin authorization error:', error);
    return res.status(500).json({ error: 'เกิดข้อผิดพลาดในการตรวจสอบสิทธิ์ผู้ดูแลระบบ' });
  }
};

const recordAdminAction = async (client, req, action, resource, resultStatus = 'SUCCESS') => {
  await client.query(
    `INSERT INTO system_logs (user_id, username, action, resource, result_status, ip_address)
     VALUES ($1, $2, $3, $4, $5, $6)`,
    [req.session.user.id, req.session.user.username, action, resource, resultStatus, req.ip]
  );
};

router.use(requireAdmin);

router.get('/roles', async (req, res) => {
  try {
    const result = await db.query(
      'SELECT id, name, description FROM roles ORDER BY id'
    );
    return res.json(result.rows);
  } catch (error) {
    console.error('Load roles error:', error);
    return res.status(500).json({ error: 'ไม่สามารถโหลดรายการ Role ได้' });
  }
});

router.post('/roles', async (req, res) => {
  const { name, description = '' } = req.body || {};
  if (typeof name !== 'string' || !name.trim() || name.trim().length > 50 ||
      typeof description !== 'string') {
    return res.status(400).json({ error: 'กรุณาระบุชื่อ Role (ไม่เกิน 50 ตัวอักษร) และคำอธิบายที่ถูกต้อง' });
  }

  let client;
  try {
    client = await db.connect();
    await client.query('BEGIN');
    const result = await client.query(
      'INSERT INTO roles (name, description) VALUES ($1, $2) RETURNING id, name, description',
      [name.trim(), description.trim() || null]
    );
    await recordAdminAction(client, req, 'ROLE_CREATE', `role:${result.rows[0].id}`);
    await client.query('COMMIT');
    return res.status(201).json(result.rows[0]);
  } catch (error) {
    if (client) await client.query('ROLLBACK');
    if (error.code === '23505' && error.constraint === 'roles_name_key') {
      return res.status(409).json({ error: 'มีชื่อ Role นี้อยู่แล้ว' });
    }
    console.error('Create role error:', error);
    return res.status(500).json({ error: 'ไม่สามารถเพิ่ม Role ได้' });
  } finally {
    if (client) client.release();
  }
});

router.put('/roles/:id', async (req, res) => {
  const roleId = Number(req.params.id);
  const { name, description = '' } = req.body || {};

  if (!Number.isInteger(roleId) || roleId < 1) {
    return res.status(400).json({ error: 'Role ID ไม่ถูกต้อง' });
  }
  if (roleId === 1) {
    return res.status(403).json({ error: 'ไม่อนุญาตให้แก้ไข Role ผู้ดูแลระบบหลัก' });
  }
  if (typeof name !== 'string' || !name.trim() || name.trim().length > 50 ||
      typeof description !== 'string') {
    return res.status(400).json({ error: 'กรุณาระบุชื่อ Role (ไม่เกิน 50 ตัวอักษร) และคำอธิบายที่ถูกต้อง' });
  }

  try {
    const result = await db.query(
      `UPDATE roles SET name = $1, description = $2
       WHERE id = $3 RETURNING id, name, description`,
      [name.trim(), description.trim() || null, roleId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'ไม่พบ Role ที่ต้องการแก้ไข' });
    }

    await db.query(
      `INSERT INTO system_logs (user_id, username, action, resource, result_status, ip_address)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [req.session.user.id, req.session.user.username, 'ROLE_UPDATE', `role:${roleId}`, 'SUCCESS', req.ip]
    );
    return res.json(result.rows[0]);
  } catch (error) {
    if (error.code === '23505' && error.constraint === 'roles_name_key') {
      return res.status(409).json({ error: 'มีชื่อ Role นี้อยู่แล้ว' });
    }
    console.error('Update role error:', error);
    return res.status(500).json({ error: 'ไม่สามารถแก้ไข Role ได้' });
  }
});

router.delete('/roles/:id', async (req, res) => {
  const roleId = Number(req.params.id);
  if (!Number.isInteger(roleId) || roleId < 1) {
    return res.status(400).json({ error: 'Role ID ไม่ถูกต้อง' });
  }
  if (roleId <= 4) {
    return res.status(403).json({ error: 'ไม่อนุญาตให้ลบ Role มาตรฐานของระบบ' });
  }

  let client;
  try {
    client = await db.connect();
    await client.query('BEGIN');
    const result = await client.query(
      'DELETE FROM roles WHERE id = $1 RETURNING id',
      [roleId]
    );

    if (result.rows.length === 0) {
      if (client) await client.query('ROLLBACK');
      return res.status(404).json({ error: 'ไม่พบ Role ที่ต้องการลบ' });
    }

    await recordAdminAction(client, req, 'ROLE_DELETE', `role:${roleId}`);
    await client.query('COMMIT');
    return res.json({ message: 'ลบ Role สำเร็จ' });
  } catch (error) {
    if (client) await client.query('ROLLBACK');
    if (error.code === '23503') {
      return res.status(409).json({ error: 'Role นี้ยังมีผู้ใช้งานอยู่ จึงไม่สามารถลบได้' });
    }
    console.error('Delete role error:', error);
    return res.status(500).json({ error: 'ไม่สามารถลบ Role ได้' });
  } finally {
    if (client) client.release();
  }
});

router.get('/permissions', async (req, res) => {
  try {
    const result = await db.query(
      'SELECT id, name, description FROM permissions ORDER BY id'
    );
    return res.json(result.rows);
  } catch (error) {
    console.error('Load permissions error:', error);
    return res.status(500).json({ error: 'ไม่สามารถโหลดรายการ Permission ได้' });
  }
});

router.post('/permissions', async (req, res) => {
  const { name, description = '' } = req.body || {};
  if (typeof name !== 'string' || !name.trim() || name.trim().length > 100 ||
      typeof description !== 'string') {
    return res.status(400).json({ error: 'กรุณาระบุชื่อ Permission (ไม่เกิน 100 ตัวอักษร) และคำอธิบายที่ถูกต้อง' });
  }

  let client;
  try {
    client = await db.connect();
    await client.query('BEGIN');
    const result = await client.query(
      'INSERT INTO permissions (name, description) VALUES ($1, $2) RETURNING id, name, description',
      [name.trim(), description.trim() || null]
    );
    await recordAdminAction(client, req, 'PERMISSION_CREATE', `permission:${result.rows[0].id}`);
    await client.query('COMMIT');
    return res.status(201).json(result.rows[0]);
  } catch (error) {
    if (client) await client.query('ROLLBACK');
    if (error.code === '23505' && error.constraint === 'permissions_name_key') {
      return res.status(409).json({ error: 'มีชื่อ Permission นี้อยู่แล้ว' });
    }
    console.error('Create permission error:', error);
    return res.status(500).json({ error: 'ไม่สามารถเพิ่ม Permission ได้' });
  } finally {
    if (client) client.release();
  }
});

router.put('/permissions/:id', async (req, res) => {
  const permissionId = Number(req.params.id);
  const { name, description = '' } = req.body || {};
  if (!Number.isInteger(permissionId) || permissionId < 1 ||
      typeof name !== 'string' || !name.trim() || name.trim().length > 100 ||
      typeof description !== 'string') {
    return res.status(400).json({ error: 'กรุณาระบุข้อมูล Permission ให้ถูกต้อง' });
  }

  try {
    const result = await db.query(
      `UPDATE permissions SET name = $1, description = $2
       WHERE id = $3 RETURNING id, name, description`,
      [name.trim(), description.trim() || null, permissionId]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'ไม่พบ Permission ที่ต้องการแก้ไข' });
    }

    await db.query(
      `INSERT INTO system_logs (user_id, username, action, resource, result_status, ip_address)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [req.session.user.id, req.session.user.username, 'PERMISSION_UPDATE', `permission:${permissionId}`, 'SUCCESS', req.ip]
    );
    return res.json(result.rows[0]);
  } catch (error) {
    if (error.code === '23505' && error.constraint === 'permissions_name_key') {
      return res.status(409).json({ error: 'มีชื่อ Permission นี้อยู่แล้ว' });
    }
    console.error('Update permission error:', error);
    return res.status(500).json({ error: 'ไม่สามารถแก้ไข Permission ได้' });
  }
});

router.delete('/permissions/:id', async (req, res) => {
  const permissionId = Number(req.params.id);
  if (!Number.isInteger(permissionId) || permissionId < 1) {
    return res.status(400).json({ error: 'Permission ID ไม่ถูกต้อง' });
  }

  let client;
  try {
    client = await db.connect();
    await client.query('BEGIN');
    const result = await client.query(
      'DELETE FROM permissions WHERE id = $1 RETURNING id',
      [permissionId]
    );
    if (result.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'ไม่พบ Permission ที่ต้องการลบ' });
    }

    await recordAdminAction(client, req, 'PERMISSION_DELETE', `permission:${permissionId}`);
    await client.query('COMMIT');
    return res.json({ message: 'ลบ Permission สำเร็จ' });
  } catch (error) {
    if (client) await client.query('ROLLBACK');
    console.error('Delete permission error:', error);
    return res.status(500).json({ error: 'ไม่สามารถลบ Permission ได้' });
  } finally {
    if (client) client.release();
  }
});

router.get('/users', async (req, res) => {
  try {
    const result = await db.query(
      `SELECT u.id, u.username, u.role_id, r.name AS role_name, u.created_at
       FROM users u
       LEFT JOIN roles r ON r.id = u.role_id
       ORDER BY u.id`
    );
    return res.json(result.rows);
  } catch (error) {
    console.error('Load users error:', error);
    return res.status(500).json({ error: 'ไม่สามารถโหลดผู้ใช้ได้' });
  }
});

router.post('/users', async (req, res) => {
  const { username, password, role_id: roleIdValue } = req.body || {};
  const roleId = Number(roleIdValue);
  if (typeof username !== 'string' || !username.trim() || username.trim().length > 50 ||
      typeof password !== 'string' || password.length < 6 ||
      !Number.isInteger(roleId) || roleId < 1) {
    return res.status(400).json({ error: 'กรุณาระบุ Username, รหัสผ่านอย่างน้อย 6 ตัว และ Role ให้ถูกต้อง' });
  }

  let client;
  try {
    client = await db.connect();
    await client.query('BEGIN');
    const role = await client.query('SELECT id FROM roles WHERE id = $1', [roleId]);
    if (role.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'ไม่พบ Role ที่เลือก' });
    }
    const passwordHash = await bcrypt.hash(password, 10);
    const result = await client.query(
      `INSERT INTO users (username, password_hash, role_id)
       VALUES ($1, $2, $3)
       RETURNING id, username, role_id`,
      [username.trim(), passwordHash, roleId]
    );
    await recordAdminAction(client, req, 'USER_CREATE', `user:${result.rows[0].id}`);
    await client.query('COMMIT');
    return res.status(201).json(result.rows[0]);
  } catch (error) {
    if (client) await client.query('ROLLBACK');
    if (error.code === '23505' && error.constraint === 'users_username_key') {
      return res.status(409).json({ error: 'Username นี้มีอยู่แล้ว' });
    }
    console.error('Create user error:', error);
    return res.status(500).json({ error: 'ไม่สามารถเพิ่มผู้ใช้ได้' });
  } finally {
    if (client) client.release();
  }
});

router.put('/users/:id', async (req, res) => {
  const userId = Number(req.params.id);
  const { role_id: roleIdValue, password } = req.body || {};
  const roleId = Number(roleIdValue);
  if (!Number.isInteger(userId) || userId < 1 ||
      !Number.isInteger(roleId) || roleId < 1 ||
      (password !== undefined && (typeof password !== 'string' || password.length < 6))) {
    return res.status(400).json({ error: 'ข้อมูลผู้ใช้ไม่ถูกต้อง (รหัสผ่านต้องมีอย่างน้อย 6 ตัว)' });
  }

  let client;
  try {
    client = await db.connect();
    await client.query('BEGIN');
    const role = await client.query('SELECT id FROM roles WHERE id = $1', [roleId]);
    if (role.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'ไม่พบ Role ที่เลือก' });
    }

    const result = password
      ? await client.query(
        `UPDATE users SET role_id = $1, password_hash = $2
         WHERE id = $3 RETURNING id, username, role_id`,
        [roleId, await bcrypt.hash(password, 10), userId]
      )
      : await client.query(
        'UPDATE users SET role_id = $1 WHERE id = $2 RETURNING id, username, role_id',
        [roleId, userId]
      );

    if (result.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'ไม่พบผู้ใช้ที่ต้องการแก้ไข' });
    }
    await recordAdminAction(client, req, 'USER_UPDATE', `user:${userId}`);
    await client.query('COMMIT');
    return res.json(result.rows[0]);
  } catch (error) {
    if (client) await client.query('ROLLBACK');
    console.error('Update user error:', error);
    return res.status(500).json({ error: 'ไม่สามารถแก้ไขผู้ใช้ได้' });
  } finally {
    if (client) client.release();
  }
});

router.delete('/users/:id', async (req, res) => {
  const userId = Number(req.params.id);
  if (!Number.isInteger(userId) || userId < 1) {
    return res.status(400).json({ error: 'User ID ไม่ถูกต้อง' });
  }
  if (Number(req.session.user.id) === userId) {
    return res.status(403).json({ error: 'ไม่สามารถลบบัญชีที่กำลังใช้งานอยู่ได้' });
  }

  let client;
  try {
    client = await db.connect();
    await client.query('BEGIN');
    const user = await client.query(
      'SELECT id, role_id FROM users WHERE id = $1 FOR UPDATE',
      [userId]
    );
    if (user.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'ไม่พบผู้ใช้ที่ต้องการลบ' });
    }

    if (Number(user.rows[0].role_id) === 1) {
      const admins = await client.query(
        'SELECT COUNT(*)::int AS count FROM users WHERE role_id = 1'
      );
      if (admins.rows[0].count <= 1) {
        await client.query('ROLLBACK');
        return res.status(409).json({ error: 'ระบบต้องมี Admin อย่างน้อยหนึ่งบัญชี' });
      }
    }

    await client.query('DELETE FROM users WHERE id = $1', [userId]);
    await recordAdminAction(client, req, 'USER_DELETE', `user:${userId}`);
    await client.query('COMMIT');
    return res.json({ message: 'ลบผู้ใช้สำเร็จ' });
  } catch (error) {
    if (client) await client.query('ROLLBACK');
    if (error.code === '23503') {
      return res.status(409).json({ error: 'ผู้ใช้นี้มีประวัติการยืม จึงไม่สามารถลบได้' });
    }
    console.error('Delete user error:', error);
    return res.status(500).json({ error: 'ไม่สามารถลบผู้ใช้ได้' });
  } finally {
    if (client) client.release();
  }
});

router.get('/roles/:id/permissions', async (req, res) => {
  const roleId = Number(req.params.id);
  if (!Number.isInteger(roleId) || roleId < 1) {
    return res.status(400).json({ error: 'Role ID ไม่ถูกต้อง' });
  }

  try {
    const result = await db.query(
      `SELECT p.id, p.name, p.description
       FROM role_permissions rp
       JOIN permissions p ON p.id = rp.permission_id
       WHERE rp.role_id = $1
       ORDER BY p.id`,
      [roleId]
    );
    return res.json(result.rows);
  } catch (error) {
    console.error('Load role permissions error:', error);
    return res.status(500).json({ error: 'ไม่สามารถโหลดสิทธิ์ของ Role ได้' });
  }
});

router.put('/roles/:id/permissions', async (req, res) => {
  const roleId = Number(req.params.id);
  const { permission_ids: permissionIds } = req.body || {};

  if (!Number.isInteger(roleId) || roleId < 1) {
    return res.status(400).json({ error: 'Role ID ไม่ถูกต้อง' });
  }
  if (roleId === 1) {
    return res.status(403).json({ error: 'Role ผู้ดูแลระบบหลักมีสิทธิ์ทั้งหมดและไม่สามารถแก้ไข ACL ได้' });
  }
  if (!Array.isArray(permissionIds) ||
      permissionIds.some((id) => !Number.isInteger(id) || id < 1) ||
      new Set(permissionIds).size !== permissionIds.length) {
    return res.status(400).json({ error: 'รายการ Permission ไม่ถูกต้อง' });
  }

  let client;
  try {
    client = await db.connect();
    await client.query('BEGIN');

    const roleResult = await client.query('SELECT id FROM roles WHERE id = $1', [roleId]);
    if (roleResult.rows.length === 0) {
      if (client) await client.query('ROLLBACK');
      return res.status(404).json({ error: 'ไม่พบ Role ที่ต้องการกำหนดสิทธิ์' });
    }

    if (permissionIds.length > 0) {
      const permissionsResult = await client.query(
        'SELECT id FROM permissions WHERE id = ANY($1::int[])',
        [permissionIds]
      );
      if (permissionsResult.rows.length !== permissionIds.length) {
        await client.query('ROLLBACK');
        return res.status(400).json({ error: 'พบ Permission ที่ไม่มีอยู่ในระบบ' });
      }
    }

    await client.query('DELETE FROM role_permissions WHERE role_id = $1', [roleId]);
    for (const permissionId of permissionIds) {
      await client.query(
        'INSERT INTO role_permissions (role_id, permission_id) VALUES ($1, $2)',
        [roleId, permissionId]
      );
    }

    await recordAdminAction(client, req, 'ACL_UPDATE', `role:${roleId}`);
    await client.query('COMMIT');
    return res.json({ message: 'อัปเดตสิทธิ์ ACL สำเร็จ', permission_ids: permissionIds });
  } catch (error) {
    if (client) await client.query('ROLLBACK');
    console.error('Update ACL error:', error);
    return res.status(500).json({ error: 'ไม่สามารถอัปเดตสิทธิ์ ACL ได้' });
  } finally {
    if (client) client.release();
  }
});

router.get('/logs', async (req, res) => {
  try {
    const result = await db.query(
      `SELECT created_at, username, action, resource, result_status, ip_address
       FROM system_logs
       ORDER BY created_at DESC
       LIMIT 200`
    );
    return res.json(result.rows);
  } catch (error) {
    console.error('Load system logs error:', error);
    return res.status(500).json({ error: 'ไม่สามารถโหลด Logs ได้' });
  }
});

module.exports = { router, requireAdmin };
