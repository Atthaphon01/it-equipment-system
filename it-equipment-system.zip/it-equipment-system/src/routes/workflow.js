const express = require('express');
const fs = require('fs/promises');
const path = require('path');
const db = require('../config/db');
const upload = require('../middlewares/upload');
const { requireAuth, checkPermission, requireAnyPermission } = require('../middlewares/auth');

const router = express.Router();
const uploadDirectory = path.join(__dirname, '../../public/uploads');
const datePattern = /^\d{4}-\d{2}-\d{2}$/;

router.use(requireAuth);

const receiveUpload = (fieldName) => (req, res, next) => {
  upload.single(fieldName)(req, res, (error) => {
    if (error) {
      const status = error.code === 'LIMIT_FILE_SIZE' ? 413 : 400;
      return res.status(status).json({ error: status === 413 ? 'ไฟล์ต้องมีขนาดไม่เกิน 5 MB' : error.message });
    }
    if (req.fileValidationError) {
      return res.status(400).json({ error: req.fileValidationError });
    }
    return next();
  });
};

const removeUploadedFile = async (file) => {
  if (!file) return;
  try {
    await fs.unlink(file.path);
  } catch (error) {
    if (error.code !== 'ENOENT') console.error('Uploaded file cleanup error:', error);
  }
};

const recordAction = (client, req, action, resource) => client.query(
  `INSERT INTO system_logs (user_id, username, action, resource, result_status, ip_address)
   VALUES ($1, $2, $3, $4, $5, $6)`,
  [req.session.user.id, req.session.user.username, action, resource, 'SUCCESS', req.ip]
);

const isDate = (value) => {
  if (typeof value !== 'string' || !datePattern.test(value)) return false;
  const parsed = new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
};

router.get('/equipments', checkPermission('equipment.read'), async (req, res) => {
  try {
    const result = await db.query(
      `SELECT id, name, serial_number, image_url, status
       FROM equipments
       ORDER BY name, id`
    );
    return res.json(result.rows);
  } catch (error) {
    console.error('Load equipment error:', error);
    return res.status(500).json({ error: 'ไม่สามารถโหลดรายการอุปกรณ์ได้' });
  }
});

router.post('/equipments', checkPermission('equipment.create'), receiveUpload('image'), async (req, res) => {
  const { name, serial_number: serialNumber } = req.body || {};
  if (typeof name !== 'string' || !name.trim() || name.trim().length > 100 ||
      typeof serialNumber !== 'string' || !serialNumber.trim() || serialNumber.trim().length > 50) {
    await removeUploadedFile(req.file);
    return res.status(400).json({ error: 'กรุณาระบุชื่ออุปกรณ์และ Serial Number ให้ถูกต้อง' });
  }
  if (req.file && !['image/jpeg', 'image/png'].includes(req.file.mimetype)) {
    await removeUploadedFile(req.file);
    return res.status(400).json({ error: 'รูปอุปกรณ์ต้องเป็นไฟล์ JPG หรือ PNG เท่านั้น' });
  }

  let client;
  try {
    client = await db.connect();
    await client.query('BEGIN');
    const result = await client.query(
      `INSERT INTO equipments (name, serial_number, image_url)
       VALUES ($1, $2, $3)
       RETURNING id, name, serial_number, image_url, status`,
      [name.trim(), serialNumber.trim(), req.file?.filename || null]
    );
    await recordAction(client, req, 'EQUIPMENT_CREATE', `equipment:${result.rows[0].id}`);
    await client.query('COMMIT');
    return res.status(201).json(result.rows[0]);
  } catch (error) {
    if (client) await client.query('ROLLBACK');
    await removeUploadedFile(req.file);
    if (error.code === '23505') {
      return res.status(409).json({ error: 'Serial Number นี้มีอยู่ในระบบแล้ว' });
    }
    console.error('Create equipment error:', error);
    return res.status(500).json({ error: 'ไม่สามารถเพิ่มอุปกรณ์ได้' });
  } finally {
    if (client) client.release();
  }
});

router.put('/equipments/:id', checkPermission('equipment.update'), receiveUpload('image'), async (req, res) => {
  const equipmentId = Number(req.params.id);
  const { name, serial_number: serialNumber } = req.body || {};
  if (!Number.isInteger(equipmentId) || equipmentId < 1 ||
      typeof name !== 'string' || !name.trim() || name.trim().length > 100 ||
      typeof serialNumber !== 'string' || !serialNumber.trim() || serialNumber.trim().length > 50) {
    await removeUploadedFile(req.file);
    return res.status(400).json({ error: 'กรุณาระบุข้อมูลอุปกรณ์ให้ถูกต้อง' });
  }
  if (req.file && !['image/jpeg', 'image/png'].includes(req.file.mimetype)) {
    await removeUploadedFile(req.file);
    return res.status(400).json({ error: 'รูปอุปกรณ์ต้องเป็นไฟล์ JPG หรือ PNG เท่านั้น' });
  }

  let client;
  try {
    client = await db.connect();
    await client.query('BEGIN');
    const result = await client.query(
      `UPDATE equipments
       SET name = $1, serial_number = $2, image_url = COALESCE($3, image_url)
       WHERE id = $4
       RETURNING id, name, serial_number, image_url, status`,
      [name.trim(), serialNumber.trim(), req.file?.filename || null, equipmentId]
    );
    if (result.rows.length === 0) {
      if (client) await client.query('ROLLBACK');
      await removeUploadedFile(req.file);
      return res.status(404).json({ error: 'ไม่พบอุปกรณ์ที่ต้องการแก้ไข' });
    }
    await recordAction(client, req, 'EQUIPMENT_UPDATE', `equipment:${equipmentId}`);
    await client.query('COMMIT');
    return res.json(result.rows[0]);
  } catch (error) {
    if (client) await client.query('ROLLBACK');
    await removeUploadedFile(req.file);
    if (error.code === '23505') {
      return res.status(409).json({ error: 'Serial Number นี้มีอยู่ในระบบแล้ว' });
    }
    console.error('Update equipment error:', error);
    return res.status(500).json({ error: 'ไม่สามารถแก้ไขอุปกรณ์ได้' });
  } finally {
    if (client) client.release();
  }
});

router.get('/requests/mine', checkPermission('borrow.request'), async (req, res) => {
  try {
    const result = await db.query(
      `SELECT br.id, br.equipment_id, e.name AS equipment_name, e.serial_number,
              br.status, br.document_path, br.borrow_date, br.return_date, br.created_at
       FROM borrow_requests br
       JOIN equipments e ON e.id = br.equipment_id
       WHERE br.user_id = $1
       ORDER BY br.created_at DESC`,
      [req.session.user.id]
    );
    return res.json(result.rows);
  } catch (error) {
    console.error('Load personal borrow history error:', error);
    return res.status(500).json({ error: 'ไม่สามารถโหลดประวัติการยืมได้' });
  }
});

router.post('/requests', checkPermission('borrow.request'), receiveUpload('document'), async (req, res) => {
  const { equipment_id: equipmentIdValue, borrow_date: borrowDate, return_date: returnDate } = req.body || {};
  const equipmentId = Number(equipmentIdValue);
  if (!Number.isInteger(equipmentId) || equipmentId < 1 ||
      !isDate(borrowDate) || !isDate(returnDate) ||
      borrowDate < new Date().toISOString().slice(0, 10) || returnDate < borrowDate) {
    await removeUploadedFile(req.file);
    return res.status(400).json({ error: 'กรุณาเลือกอุปกรณ์และวันที่ยืม/คืนให้ถูกต้อง' });
  }
  if (req.file && req.file.mimetype !== 'application/pdf') {
    await removeUploadedFile(req.file);
    return res.status(400).json({ error: 'เอกสารประกอบต้องเป็นไฟล์ PDF เท่านั้น' });
  }

  let client;
  try {
    client = await db.connect();
    await client.query('BEGIN');
    const equipment = await client.query(
      'SELECT id, status FROM equipments WHERE id = $1 FOR UPDATE',
      [equipmentId]
    );
    if (equipment.rows.length === 0) {
      if (client) await client.query('ROLLBACK');
      await removeUploadedFile(req.file);
      return res.status(404).json({ error: 'ไม่พบอุปกรณ์ที่เลือก' });
    }
    if (equipment.rows[0].status !== 'AVAILABLE') {
      await client.query('ROLLBACK');
      await removeUploadedFile(req.file);
      return res.status(409).json({ error: 'อุปกรณ์นี้ไม่พร้อมให้ยืมในขณะนี้' });
    }

    const result = await client.query(
      `INSERT INTO borrow_requests (user_id, equipment_id, status, document_path, borrow_date, return_date)
       VALUES ($1, $2, 'PENDING', $3, $4, $5)
       RETURNING id, equipment_id, status, document_path, borrow_date, return_date, created_at`,
      [req.session.user.id, equipmentId, req.file?.filename || null, borrowDate, returnDate]
    );
    await client.query(
      "UPDATE equipments SET status = 'RESERVED' WHERE id = $1",
      [equipmentId]
    );
    await recordAction(client, req, 'BORROW_REQUEST_CREATE', `borrow_request:${result.rows[0].id}`);
    await client.query('COMMIT');
    return res.status(201).json(result.rows[0]);
  } catch (error) {
    if (client) await client.query('ROLLBACK');
    await removeUploadedFile(req.file);
    console.error('Create borrow request error:', error);
    return res.status(500).json({ error: 'ไม่สามารถส่งคำขอยืมได้' });
  } finally {
    if (client) client.release();
  }
});

router.get('/requests', requireAnyPermission(['borrow.approve', 'borrow.manage_return']), async (req, res) => {
  try {
    const result = await db.query(
      `SELECT br.id, br.user_id, u.username, br.equipment_id, e.name AS equipment_name,
              e.serial_number, br.status, br.document_path, br.borrow_date,
              br.return_date, br.created_at
       FROM borrow_requests br
       JOIN users u ON u.id = br.user_id
       JOIN equipments e ON e.id = br.equipment_id
       ORDER BY br.created_at DESC, br.id DESC`
    );
    return res.json(result.rows);
  } catch (error) {
    console.error('Load borrow requests error:', error);
    return res.status(500).json({ error: 'ไม่สามารถโหลดรายการคำขอยืมได้' });
  }
});

router.post('/requests/:id/decision', checkPermission('borrow.approve'), async (req, res) => {
  const requestId = Number(req.params.id);
  const { decision } = req.body || {};
  if (!Number.isInteger(requestId) || requestId < 1 ||
      !['APPROVED', 'REJECTED'].includes(decision)) {
    return res.status(400).json({ error: 'ข้อมูลการพิจารณาคำขอไม่ถูกต้อง' });
  }

  let client;
  try {
    client = await db.connect();
    await client.query('BEGIN');
    const request = await client.query(
      'SELECT id, equipment_id, status FROM borrow_requests WHERE id = $1 FOR UPDATE',
      [requestId]
    );
    if (request.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'ไม่พบคำขอยืมนี้' });
    }
    if (request.rows[0].status !== 'PENDING') {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: 'คำขอนี้ได้รับการดำเนินการแล้ว' });
    }

    if (decision === 'APPROVED') {
      const equipment = await client.query(
        'SELECT status FROM equipments WHERE id = $1 FOR UPDATE',
        [request.rows[0].equipment_id]
      );
      if (!equipment.rows.length || equipment.rows[0].status !== 'RESERVED') {
        await client.query('ROLLBACK');
        return res.status(409).json({ error: 'สถานะอุปกรณ์ไม่พร้อมสำหรับคำขอนี้' });
      }
    } else {
      await client.query(
        "UPDATE equipments SET status = 'AVAILABLE' WHERE id = $1 AND status = 'RESERVED'",
        [request.rows[0].equipment_id]
      );
    }

    await client.query(
      'UPDATE borrow_requests SET status = $1 WHERE id = $2',
      [decision, requestId]
    );
    await recordAction(client, req, `BORROW_REQUEST_${decision}`, `borrow_request:${requestId}`);
    await client.query('COMMIT');
    return res.json({ message: decision === 'APPROVED' ? 'อนุมัติคำขอสำเร็จ' : 'ปฏิเสธคำขอสำเร็จ' });
  } catch (error) {
    if (client) await client.query('ROLLBACK');
    console.error('Decide borrow request error:', error);
    return res.status(500).json({ error: 'ไม่สามารถบันทึกผลการพิจารณาได้' });
  } finally {
    if (client) client.release();
  }
});

router.post('/requests/:id/checkout', checkPermission('borrow.manage_return'), async (req, res) => {
  const requestId = Number(req.params.id);
  if (!Number.isInteger(requestId) || requestId < 1) {
    return res.status(400).json({ error: 'Request ID ไม่ถูกต้อง' });
  }

  let client;
  try {
    client = await db.connect();
    await client.query('BEGIN');
    const request = await client.query(
      'SELECT id, equipment_id, status FROM borrow_requests WHERE id = $1 FOR UPDATE',
      [requestId]
    );
    if (request.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'ไม่พบคำขอยืมนี้' });
    }
    if (request.rows[0].status !== 'APPROVED') {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: 'คำขอต้องได้รับอนุมัติก่อนบันทึกการส่งมอบ' });
    }
    const equipment = await client.query(
      'SELECT status FROM equipments WHERE id = $1 FOR UPDATE',
      [request.rows[0].equipment_id]
    );
    if (equipment.rows[0]?.status !== 'RESERVED') {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: 'สถานะอุปกรณ์ไม่พร้อมสำหรับการส่งมอบ' });
    }

    await client.query("UPDATE equipments SET status = 'BORROWED' WHERE id = $1", [request.rows[0].equipment_id]);
    await client.query("UPDATE borrow_requests SET status = 'BORROWED' WHERE id = $1", [requestId]);
    await recordAction(client, req, 'EQUIPMENT_CHECKOUT', `borrow_request:${requestId}`);
    await client.query('COMMIT');
    return res.json({ message: 'บันทึกการส่งมอบอุปกรณ์สำเร็จ' });
  } catch (error) {
    if (client) await client.query('ROLLBACK');
    console.error('Checkout equipment error:', error);
    return res.status(500).json({ error: 'ไม่สามารถบันทึกการส่งมอบได้' });
  } finally {
    if (client) client.release();
  }
});

router.delete('/requests/:id/document', checkPermission('borrow.manage_return'), async (req, res) => {
  const requestId = Number(req.params.id);
  if (!Number.isInteger(requestId) || requestId < 1) {
    return res.status(400).json({ error: 'Request ID ไม่ถูกต้อง' });
  }

  let client;
  try {
    client = await db.connect();
    await client.query('BEGIN');
    const result = await client.query(
      'SELECT document_path FROM borrow_requests WHERE id = $1 FOR UPDATE',
      [requestId]
    );
    if (result.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'ไม่พบคำขอยืมนี้' });
    }
    const fileName = result.rows[0].document_path;
    if (!fileName) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'คำขอนี้ไม่มีเอกสารแนบ' });
    }

    await client.query(
      'UPDATE borrow_requests SET document_path = NULL WHERE id = $1',
      [requestId]
    );
    await recordAction(client, req, 'BORROW_DOCUMENT_DELETE', `borrow_request:${requestId}`);
    await client.query('COMMIT');

    try {
      const references = await db.query(
        `SELECT EXISTS (SELECT 1 FROM borrow_requests WHERE document_path = $1)
                OR EXISTS (SELECT 1 FROM equipments WHERE image_url = $1) AS in_use`,
        [fileName]
      );
      if (!references.rows[0].in_use) {
        await fs.unlink(path.join(uploadDirectory, fileName));
      }
      return res.json({ message: 'ลบเอกสารแนบสำเร็จ' });
    } catch (error) {
      if (error.code === 'ENOENT') return res.json({ message: 'ลบเอกสารแนบสำเร็จ' });
      console.error('Delete borrow attachment file error:', error);
      return res.json({
        message: 'ลบรายการเอกสารแนบแล้ว',
        warning: 'ไม่สามารถลบไฟล์ออกจากพื้นที่จัดเก็บได้ กรุณาแจ้งผู้ดูแลระบบ'
      });
    }
  } catch (error) {
    if (client) await client.query('ROLLBACK');
    console.error('Delete borrow attachment error:', error);
    return res.status(500).json({ error: 'ไม่สามารถลบเอกสารแนบได้' });
  } finally {
    if (client) client.release();
  }
});

router.post('/requests/:id/return', checkPermission('borrow.manage_return'), async (req, res) => {
  const requestId = Number(req.params.id);
  if (!Number.isInteger(requestId) || requestId < 1) {
    return res.status(400).json({ error: 'Request ID ไม่ถูกต้อง' });
  }

  let client;
  try {
    client = await db.connect();
    await client.query('BEGIN');
    const request = await client.query(
      'SELECT id, equipment_id, status FROM borrow_requests WHERE id = $1 FOR UPDATE',
      [requestId]
    );
    if (request.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'ไม่พบคำขอยืมนี้' });
    }
    if (request.rows[0].status !== 'BORROWED') {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: 'อุปกรณ์นี้ยังไม่ได้ถูกส่งมอบหรือถูกรับคืนแล้ว' });
    }

    await client.query("UPDATE equipments SET status = 'AVAILABLE' WHERE id = $1", [request.rows[0].equipment_id]);
    await client.query("UPDATE borrow_requests SET status = 'RETURNED' WHERE id = $1", [requestId]);
    await recordAction(client, req, 'EQUIPMENT_RETURN', `borrow_request:${requestId}`);
    await client.query('COMMIT');
    return res.json({ message: 'บันทึกการรับคืนอุปกรณ์สำเร็จ' });
  } catch (error) {
    if (client) await client.query('ROLLBACK');
    console.error('Return equipment error:', error);
    return res.status(500).json({ error: 'ไม่สามารถบันทึกการรับคืนได้' });
  } finally {
    if (client) client.release();
  }
});

router.get('/manager/summary', checkPermission('borrow.approve'), async (req, res) => {
  try {
    const result = await db.query(
      `SELECT
         COUNT(*) FILTER (WHERE status = 'PENDING')::int AS pending,
         COUNT(*) FILTER (WHERE status = 'APPROVED')::int AS approved,
         COUNT(*) FILTER (WHERE status = 'BORROWED')::int AS borrowed,
         COUNT(*) FILTER (WHERE status = 'REJECTED')::int AS rejected,
         COUNT(*) FILTER (WHERE status = 'RETURNED')::int AS returned,
         COUNT(*) FILTER (WHERE status = 'BORROWED' AND return_date < CURRENT_DATE)::int AS overdue
       FROM borrow_requests`
    );
    return res.json(result.rows[0]);
  } catch (error) {
    console.error('Load manager summary error:', error);
    return res.status(500).json({ error: 'ไม่สามารถโหลดรายงานสรุปได้' });
  }
});

router.get('/manager/logs', checkPermission('log.read'), async (req, res) => {
  const { from = '', to = '', result_status: resultStatus = '' } = req.query;
  if ((from && !isDate(from)) || (to && !isDate(to)) ||
      (from && to && from > to) ||
      (resultStatus && !['SUCCESS', 'DENIED', 'FAILED'].includes(resultStatus))) {
    return res.status(400).json({ error: 'เงื่อนไขการกรอง Logs ไม่ถูกต้อง' });
  }

  try {
    const result = await db.query(
      `SELECT created_at, username, action, resource, result_status, ip_address
       FROM system_logs
       WHERE ($1 = '' OR created_at >= $1::date)
         AND ($2 = '' OR created_at < ($2::date + INTERVAL '1 day'))
         AND ($3 = '' OR result_status = $3)
       ORDER BY created_at DESC
       LIMIT 500`,
      [from, to, resultStatus]
    );
    return res.json(result.rows);
  } catch (error) {
    console.error('Load manager logs error:', error);
    return res.status(500).json({ error: 'ไม่สามารถโหลด Logs ได้' });
  }
});

router.get('/files/:fileName', async (req, res) => {
  const { fileName } = req.params;
  if (!/^[a-zA-Z0-9_.-]+$/.test(fileName) || path.basename(fileName) !== fileName) {
    return res.status(400).json({ error: 'ชื่อไฟล์ไม่ถูกต้อง' });
  }

  res.setHeader('X-Content-Type-Options', 'nosniff');

  try {
    const [equipmentResult, requestResult, userResult] = await Promise.all([
      db.query('SELECT id FROM equipments WHERE image_url = $1', [fileName]),
      db.query('SELECT id, user_id FROM borrow_requests WHERE document_path = $1', [fileName]),
      db.query(
        `SELECT u.role_id, ARRAY_AGG(p.name) FILTER (WHERE p.name IS NOT NULL) AS permissions
         FROM users u
         LEFT JOIN role_permissions rp ON rp.role_id = u.role_id
         LEFT JOIN permissions p ON p.id = rp.permission_id
         WHERE u.id = $1
         GROUP BY u.id`,
        [req.session.user.id]
      )
    ]);
    const user = userResult.rows[0];
    if (!user) return res.status(401).json({ error: 'กรุณาเข้าสู่ระบบอีกครั้ง' });

    const isAdmin = Number(user.role_id) === 1;
    const permissions = user.permissions || [];
    const canReadEquipment = isAdmin || permissions.includes('equipment.read');
    const canReadBorrowDocuments = isAdmin ||
      permissions.includes('borrow.approve') ||
      permissions.includes('borrow.manage_return');
    const ownsBorrowDocument = requestResult.rows.some(
      (request) => Number(request.user_id) === Number(req.session.user.id)
    );

    if (equipmentResult.rows.length > 0 && canReadEquipment) {
      return res.sendFile(path.join(uploadDirectory, fileName), (error) => {
        if (error && !res.headersSent) {
          console.error('Serve equipment image error:', error);
          res.status(error.statusCode || 500).json({ error: 'ไม่สามารถเปิดไฟล์ได้' });
        }
      });
    }

    if (requestResult.rows.length > 0 && (canReadBorrowDocuments || ownsBorrowDocument)) {
      return res.sendFile(path.join(uploadDirectory, fileName), (error) => {
        if (error && !res.headersSent) {
          console.error('Serve borrow document error:', error);
          res.status(error.statusCode || 500).json({ error: 'ไม่สามารถเปิดไฟล์ได้' });
        }
      });
    }

    if (equipmentResult.rows.length === 0 && requestResult.rows.length === 0) {
      return res.status(404).json({ error: 'ไม่พบไฟล์ที่ร้องขอ' });
    }
    return res.status(403).json({ error: 'คุณไม่มีสิทธิ์เข้าถึงไฟล์นี้' });
  } catch (error) {
    console.error('Authorize file access error:', error);
    return res.status(500).json({ error: 'เกิดข้อผิดพลาดในการตรวจสอบไฟล์' });
  }
});

module.exports = router;
