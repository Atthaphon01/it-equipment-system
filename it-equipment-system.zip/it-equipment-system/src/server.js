require('dotenv').config();

const express = require('express');
const session = require('express-session');
const path = require('path');
const bcrypt = require('bcrypt');
const db = require('./config/db');
const { router: adminRouter, requireAdmin } = require('./routes/admin');
const workflowRouter = require('./routes/workflow');
const { requireAuth, requireRoleId } = require('./middlewares/auth');

const app = express();
const port = Number(process.env.PORT || 3000);
const sessionSecret = process.env.SESSION_SECRET;

if (!Number.isInteger(port) || port < 1 || port > 65535) {
  throw new Error('PORT must be an integer between 1 and 65535.');
}

if (!sessionSecret) {
  throw new Error('SESSION_SECRET must be set in the environment.');
}

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: sessionSecret,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production'
  }
}));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'views', 'login.html'));
});

app.get('/signup', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'views', 'signup.html'));
});

app.get(['/dashboard', '/dashboard.html'], requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'views', 'dashboard.html'));
});

app.get(['/manager', '/manager.html'], requireRoleId(2), (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'views', 'manager.html'));
});

app.get(['/staff', '/staff.html'], requireRoleId(3), (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'views', 'staff.html'));
});

app.get(['/user', '/user.html'], requireRoleId(4), (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'views', 'user.html'));
});

app.get(['/admin', '/admin.html'], requireAdmin, (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'views', 'admin.html'));
});

app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

app.post('/api/auth/login', async (req, res) => {
  const { username, password } = req.body || {};

  if (typeof username !== 'string' || typeof password !== 'string' || !username.trim() || !password) {
    return res.status(400).json({ error: 'กรุณากรอก Username และ Password' });
  }

  try {
    const result = await db.query(
      `SELECT id, username, password_hash, role_id
       FROM users
       WHERE username = $1`,
      [username.trim()]
    );
    const user = result.rows[0];

    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({ error: 'Username หรือ Password ไม่ถูกต้อง' });
    }

    req.session.regenerate((sessionError) => {
      if (sessionError) {
        console.error('Session regeneration error:', sessionError);
        return res.status(500).json({ error: 'เกิดข้อผิดพลาดในการเข้าสู่ระบบ' });
      }

      req.session.user = {
        id: user.id,
        username: user.username,
        role_id: user.role_id
      };

      req.session.save((saveError) => {
        if (saveError) {
          console.error('Session save error:', saveError);
          return res.status(500).json({ error: 'เกิดข้อผิดพลาดในการเข้าสู่ระบบ' });
        }

        return res.json({ message: 'เข้าสู่ระบบสำเร็จ' });
      });
    });
  } catch (error) {
    console.error('Login error:', error);
    return res.status(500).json({ error: 'เกิดข้อผิดพลาดในการเข้าสู่ระบบ' });
  }
});

app.post('/api/auth/register', async (req, res) => {
  const { username, password, confirmPassword } = req.body || {};
  const normalizedUsername = typeof username === 'string' ? username.trim() : '';

  if (!/^[A-Za-z0-9._-]{3,50}$/.test(normalizedUsername)) {
    return res.status(400).json({
      error: 'Username ต้องมี 3–50 ตัวอักษร และใช้ได้เฉพาะ A-Z, 0-9, จุด, ขีดกลาง หรือขีดล่าง'
    });
  }
  if (typeof password !== 'string' || password.length < 8 || Buffer.byteLength(password, 'utf8') > 72) {
    return res.status(400).json({ error: 'รหัสผ่านต้องมีอย่างน้อย 8 ตัวอักษร และไม่เกิน 72 ไบต์' });
  }
  if (password !== confirmPassword) {
    return res.status(400).json({ error: 'รหัสผ่านและการยืนยันรหัสผ่านไม่ตรงกัน' });
  }

  let client;
  try {
    client = await db.connect();
    await client.query('BEGIN');
    const defaultRole = await client.query(
      'SELECT id FROM roles WHERE id = 4 FOR SHARE'
    );
    if (defaultRole.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(503).json({ error: 'ยังไม่สามารถสมัครสมาชิกได้ กรุณาติดต่อผู้ดูแลระบบ' });
    }

    const passwordHash = await bcrypt.hash(password, 12);
    const user = await client.query(
      `INSERT INTO users (username, password_hash, role_id)
       VALUES ($1, $2, $3)
       RETURNING id, username`,
      [normalizedUsername, passwordHash, defaultRole.rows[0].id]
    );
    await client.query(
      `INSERT INTO system_logs (user_id, username, action, resource, result_status, ip_address)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [user.rows[0].id, user.rows[0].username, 'USER_REGISTER', `user:${user.rows[0].id}`, 'SUCCESS', req.ip]
    );
    await client.query('COMMIT');
    return res.status(201).json({ message: 'สมัครสมาชิกสำเร็จ กรุณาเข้าสู่ระบบ', username: user.rows[0].username });
  } catch (error) {
    if (client) await client.query('ROLLBACK');
    if (error.code === '23505' && error.constraint === 'users_username_key') {
      return res.status(409).json({ error: 'Username นี้มีผู้ใช้งานแล้ว' });
    }
    console.error('Registration error:', error);
    return res.status(500).json({ error: 'ไม่สามารถสมัครสมาชิกได้ในขณะนี้' });
  } finally {
    if (client) client.release();
  }
});

app.get('/api/auth/me', requireAuth, async (req, res) => {
  try {
    const result = await db.query(
      `SELECT u.id, u.username, u.role_id, r.name AS role_name
       FROM users u
       LEFT JOIN roles r ON r.id = u.role_id
       WHERE u.id = $1`,
      [req.session.user.id]
    );
    const user = result.rows[0];

    if (!user) {
      req.session.destroy((error) => {
        if (error) console.error('Invalid session cleanup error:', error);
        return res.status(401).json({ error: 'กรุณาเข้าสู่ระบบอีกครั้ง' });
      });
      return;
    }

    return res.json({
      id: user.id,
      username: user.username,
      role_id: user.role_id,
      role_name: user.role_name
    });
  } catch (error) {
    console.error('Load current user error:', error);
    return res.status(500).json({ error: 'ไม่สามารถโหลดข้อมูลผู้ใช้ได้' });
  }
});

app.post('/api/auth/logout', (req, res) => {
  req.session.destroy((error) => {
    if (error) {
      console.error('Logout error:', error);
      return res.status(500).json({ error: 'เกิดข้อผิดพลาดในการออกจากระบบ' });
    }

    res.clearCookie('connect.sid');
    return res.json({ message: 'ออกจากระบบสำเร็จ' });
  });
});

app.use('/api/admin', adminRouter);
app.use('/api/workflow', workflowRouter);
app.use(express.static(path.join(__dirname, '..', 'views')));

app.use((req, res) => {
  res.status(404).json({ error: 'ไม่พบเส้นทางที่ร้องขอ' });
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
